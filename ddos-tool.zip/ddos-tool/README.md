# X-DDOS

X-DDOS is one of the best DDoS tools out there. It includes a user interface for inputting a URL,  resolves the URL to an IP address, and preforms an advanced DDoS attac to the website.

## Features

- DDoS attacks
- Good user interface
- IP fetching from the URL

## Installation

To run X-DDOS, you need to have Python installed. Follow these steps to get started:

1. Download the repository as a ZIP file.

2. Extract the ZIP file in your file exporer.

3. Go in the extracted folder & open start.bat

## Usage

# Guide on how to use these tool

1. Install Python from

2. Download the repo as a ZIP

3. Go in your file explorer and extract the ZIP file

4. Go in the extracted folder and open the start.bat file

5. Enjoy!


![image](https://github.com/user-attachments/assets/cb09b2d8-c4b5-41c0-804d-cd7d8b0c30df)
